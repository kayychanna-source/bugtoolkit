package com.jaccksallas.bugtoolkit

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.os.Build
import android.os.Debug
import android.content.Intent
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.net.URLEncoder
import kotlin.concurrent.thread
import kotlin.system.measureTimeMillis

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private val logs = mutableListOf<String>()
    private var glitch = false
    private var stressRunning = false
    private var stressBytes = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(20, 33, 61)
        window.navigationBarColor = Color.rgb(20, 33, 61)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 18, 20, 20)
            setBackgroundColor(Color.rgb(245, 247, 252))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        content.addView(label("BUG TOOLKIT", 28, Color.rgb(20, 33, 61), true))
        content.addView(label("Android diagnostics • local test suite", 14, Color.DKGRAY))
        status = label("Status: Ready", 14, Color.rgb(30, 110, 70), true)
        content.addView(status)
        content.addView(section("TEST MODULES"))

        addButton(content, "Visual glitch simulator") { toggleGlitch() }
        addButton(content, "CPU benchmark") { runBenchmark() }
        addButton(content, "RAM stress test (capped)") { runMemoryTest() }
        addButton(content, "App performance snapshot") { performanceSnapshot() }
        addButton(content, "Bug reproducer notes") { bugReproducer() }
        addButton(content, "Internal log viewer") { showLogs() }
        addButton(content, "Export bug report (.txt)") { exportReport() }
        addButton(content, "Send bug report via WhatsApp") { sendReportWhatsApp() }

        content.addView(section("DEVICE"))
        content.addView(label("Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})", 14, Color.DKGRAY))
        content.addView(label("Device: ${Build.MANUFACTURER} ${Build.MODEL}", 14, Color.DKGRAY))
        content.addView(label("Memory class: ${getSystemService(android.app.ActivityManager::class.java).memoryClass} MB", 14, Color.DKGRAY))
        log("Application started")
        setContentView(root)
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            this.text = text
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(4, 10, 4, 10)
        }

    private fun section(text: String) = label(text, 13, Color.rgb(75, 91, 125), true)

    private fun addButton(parent: LinearLayout, text: String, action: () -> Unit) {
        val button = Button(this).apply {
            this.text = text
            isAllCaps = false
            setOnClickListener { action() }
        }
        parent.addView(button, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = 7
        })
    }

    private fun setStatus(message: String) {
        status.text = "Status: $message"
        log(message)
    }

    private fun log(message: String) {
        val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        logs.add("[$stamp] $message")
        if (logs.size > 500) logs.removeAt(0)
    }

    private fun toggleGlitch() {
        glitch = !glitch
        root.setBackgroundColor(if (glitch) Color.rgb(255, 226, 230) else Color.rgb(245, 247, 252))
        root.alpha = if (glitch) 0.88f else 1f
        setStatus(if (glitch) "Visual simulation ON — tap again to reset" else "Visual simulation OFF")
    }

    private fun runBenchmark() {
        setStatus("Running CPU benchmark…")
        thread {
            var checksum = 0L
            val elapsed = measureTimeMillis {
                for (i in 1..2_000_000) checksum += (i.toLong() * i) % 997
            }
            runOnUiThread { setStatus("CPU test: ${elapsed} ms • checksum $checksum") }
        }
    }

    private fun runMemoryTest() {
        if (stressRunning) {
            setStatus("Memory test already running")
            return
        }
        stressRunning = true
        setStatus("Allocating up to 32 MB for 5 seconds…")
        thread {
            val chunks = mutableListOf<ByteArray>()
            try {
                repeat(32) {
                    chunks.add(ByteArray(1024 * 1024))
                    stressBytes += 1024 * 1024
                    Thread.sleep(100)
                }
                Thread.sleep(4500)
            } catch (e: OutOfMemoryError) {
                log("Memory test reached device allocation limit")
            } finally {
                chunks.clear()
                stressBytes = 0
                stressRunning = false
                runOnUiThread { setStatus("Memory test complete; temporary allocations released") }
            }
        }
    }

    private fun performanceSnapshot() {
        val runtime = Runtime.getRuntime()
        val used = (runtime.totalMemory() - runtime.freeMemory()) / (1024 * 1024)
        val max = runtime.maxMemory() / (1024 * 1024)
        val native = Debug.getNativeHeapAllocatedSize() / (1024 * 1024)
        setStatus("Heap: $used/$max MB • Native heap: $native MB")
    }

    private fun bugReproducer() {
        val input = EditText(this).apply {
            hint = "Describe steps, expected result, actual result…"
            minLines = 4
            gravity = Gravity.TOP
        }
        AlertDialog.Builder(this)
            .setTitle("Bug reproducer notes")
            .setMessage("Record a reproducible issue. Notes are stored in the report log.")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val value = input.text.toString().trim()
                if (value.isNotEmpty()) log("REPRO: $value")
                setStatus("Reproducer notes saved")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showLogs() {
        val text = if (logs.isEmpty()) "No log entries." else logs.joinToString("\n")
        val view = TextView(this).apply {
            this.text = text
            textSize = 12f
            setTextIsSelectable(true)
            setPadding(18, 12, 18, 12)
        }
        AlertDialog.Builder(this).setTitle("Internal application log")
            .setView(ScrollView(this).apply { addView(view) })
            .setPositiveButton("Close", null).show()
    }

    private fun buildBugReport(): String = buildString {
        appendLine("BUG TOOLKIT REPORT")
        appendLine("Generated: ${Date()}")
        appendLine("Device: ${Build.MANUFACTURER} ${Build.MODEL}")
        appendLine("Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        appendLine("App version: 1.0")
        appendLine()
        appendLine("LOG")
        logs.forEach { appendLine(it) }
    }

    private fun sendReportWhatsApp() {
        val input = EditText(this).apply {
            hint = "Example: 6281234567890"
            inputType = android.text.InputType.TYPE_CLASS_PHONE
        }
        AlertDialog.Builder(this)
            .setTitle("Send bug report via WhatsApp")
            .setMessage("Enter the recipient's WhatsApp number with country code, without + or spaces. The report will be prepared in WhatsApp; you can review it before sending.")
            .setView(input)
            .setPositiveButton("Continue") { _, _ ->
                val phone = input.text.toString().filter { it.isDigit() }
                if (phone.length < 8) {
                    Toast.makeText(this, "Enter a valid number with country code", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }
                val encoded = URLEncoder.encode(buildBugReport(), "UTF-8")
                val url = "https://wa.me/$phone?text=$encoded"
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url)))
                    setStatus("WhatsApp report prepared — review and tap Send")
                } catch (e: Exception) {
                    Toast.makeText(this, "Could not open WhatsApp: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun exportReport() {
        val report = buildBugReport()
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/plain"
            putExtra(Intent.EXTRA_TITLE, "bug-toolkit-report.txt")
        }
        pendingReport = report
        @Suppress("DEPRECATION")
        startActivityForResult(intent, REQUEST_EXPORT)
    }

    @Deprecated("Activity result API kept minimal for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_EXPORT && resultCode == RESULT_OK && data?.data != null) {
            try {
                contentResolver.openOutputStream(data.data!!)?.bufferedWriter()?.use { it.write(pendingReport) }
                setStatus("Report exported")
            } catch (e: Exception) {
                setStatus("Export failed: ${e.message}")
            }
        }
    }

    companion object {
        private const val REQUEST_EXPORT = 4102
        private var pendingReport: String = ""
    }
}
