# Build APK using only an Android phone

1. Download and extract `BugToolkit-Android-Project.zip`.
2. In your phone browser, sign in to GitHub and create a **new public repository** (for example `BugToolkit`).
3. Upload the *contents* of the extracted `BugToolkit` folder to the repository. Make sure `.github/workflows/build-apk.yml` is included. If the GitHub mobile upload page hides dot-folders, use GitHub's desktop-site mode or upload the ZIP's files using a GitHub-compatible mobile client.
4. Open the repository's **Actions** tab. Select **Build BugToolkit APK**, then tap **Run workflow**.
5. Wait for the workflow to finish with a green check mark. Open that completed run and find **Artifacts** near the bottom.
6. Download `BugToolkit-debug-apk`, extract the downloaded ZIP, then tap `app-debug.apk` to install it. Android may ask you to allow installation from that browser/file manager.

The workflow builds a debug APK. It is intended for testing and is not a Play Store release. Only upload source code you are comfortable placing in a public repository; do not put passwords, tokens, or private data in it.
