# Bug Toolkit (Android)

A native Kotlin Android diagnostics app with:
- Visual glitch simulator (app UI only)
- CPU benchmark
- Capped temporary RAM allocation test (32 MB maximum, released automatically)
- App heap/native heap snapshot
- Bug reproduction notes
- Internal app event log
- TXT bug report export through Android's document picker

## Build APK
1. Install Android Studio (Hedgehog or newer) and Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Allow Gradle sync to finish.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK appears at `app/build/outputs/apk/debug/app-debug.apk`.

For a signed release APK: **Build > Generate Signed Bundle / APK > APK**.

## Compatibility
- Minimum Android: 8.0 (API 26)
- Compile/target SDK: 35
- Package: `com.jaccksallas.bugtoolkit`

## Scope
The log viewer shows this app's own diagnostic events. Android restricts ordinary apps from reading the complete system Logcat stream. The memory test is intentionally capped and temporary.
